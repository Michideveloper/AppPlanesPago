/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package backEnd;
import java.util.Vector;
/**
 *
 * @author AlumnosUTJCCD
 */
public class Planes {
    private Vector cuotas= new Vector();
    private int nCuotas;
    
    public double getPlan1(double precio){
        //PLAN 1: Contado, se hace el 15% de descuento sobre el precio de lista.
        nCuotas = 1;
        double pagoFinal = (precio - (precio*0.15));
        cuotas.add(pagoFinal);
        return pagoFinal;
    }
    public double getPlan2(double precio){
        //PLAN 2: Tres cuotas, 50% al contado y el resto en dos cuotas iguales.
        //El precio de lista se incrementa en un 10%.
        nCuotas=3;
        double pagoFinal =(precio +(precio*0.10));
        cuotas.add(pagoFinal*0.50);//50% al contado
        cuotas.add(pagoFinal*0.25);
        cuotas.add(pagoFinal*0.25);
       
        return pagoFinal;
    }
    public double getPlan3(double precio){
        //PLAN 3: Cuatro cuotas, 25% al contado y el resto en tres cuotas iguales.
        //El precio de lista se incrementa en un 15%.
        nCuotas = 4;
        double pagoFinal= (precio +(precio*0.15));
        cuotas.add(pagoFinal*0.25);
        cuotas.add(pagoFinal*0.25);
        cuotas.add(pagoFinal*0.25);
        cuotas.add(pagoFinal*0.25);
        return pagoFinal;
    }
    public double getPlan4(double precio){
        //PLAN 4: Totalmente financiado en 8 cuotas.
        //El 60% se reparte en partes iguales en las cuatro primeras cuotas,
        //el resto de la misma forma en las últimas cuatro.
        //El precio de lista se incrementa en un 25%.
         nCuotas = 8;
        double pagoFinal= (precio +(precio*0.25));
        cuotas.add(pagoFinal*0.15);
        cuotas.add(pagoFinal*0.15);
        cuotas.add(pagoFinal*0.15);
        cuotas.add(pagoFinal*0.15);
        cuotas.add(pagoFinal*0.10);
        cuotas.add(pagoFinal*0.10);
        cuotas.add(pagoFinal*0.10);
        cuotas.add(pagoFinal*0.10);
        return pagoFinal;
 
    }

    public Vector getCuotas() {
        return cuotas;
    }

    public int getnCuotas() {
        return nCuotas;
    }
}

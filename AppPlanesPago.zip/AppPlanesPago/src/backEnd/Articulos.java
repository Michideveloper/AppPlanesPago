/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package backEnd;

/**
 *
 * @author AlumnosUTJCCD
 */
/*
C001 - Comedor 4 sillas - $5690
ST02 - Smart TV LG 40' - $ 12340
M004 - Mesa de madera $ 879
L098 - Licuadora Mabe $ 430

*/
public class Articulos {
    /*
    C001 - Comedor 4 sillas - $5690
    ST02 - Smart TV LG 40' - $ 12340
    M004 - Mesa de madera $ 879
    L098 - Licuadora Mabe $ 430
    */
                                //0  ,   1  , 2    ,   3
    private String[] codigo = {"C001","ST02","M004","L098"};
    private String[] descripcion={"Comedor 4 sillas","Smart TV LG 40'","Mesa de madera","Licuadora Mabe"};
    private double[] precio={5690,12340,879,430};
   
    public String conDescripcion(int indice){
        String des = descripcion[indice];
        return des;
    }
    public double conPrecio(int indice){
        double pre = precio[indice];
        return pre;
    }

    public String[] getCodigo() {
        return codigo;
    }  

    public double contrecic(int selectedIndex) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}


